"""
Entry point for running porkbun_cli as a module: python -m porkbun_cli
"""
from .cli import main

if __name__ == "__main__":
    main()
