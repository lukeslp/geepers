---
name: dream-cascade
description: Launch hierarchical 3-tier research workflows using the Dream Cascade orchestrator. Use when (1) researching complex topics requiring multiple perspectives, (2) gathering information from multiple sources, (3) synthesizing findings into comprehensive reports, (4) running autonomous multi-agent research. Requires the MCP server to be running.
---

# Dream Cascade Research Skill

Launch hierarchical multi-agent research workflows with the Dream Cascade orchestrator.

## Architecture: 3-Tier Agent System

```
          ┌─────────────────────┐
          │      CAMINA         │  ← Executive synthesis
          │  (Tier 3: 1 agent)  │     Final report generation
          └──────────┬──────────┘
                     │
       ┌─────────────┼─────────────┐
       │             │             │
  ┌────▼────┐  ┌────▼────┐  ┌────▼────┐
  │ DRUMMER │  │ DRUMMER │  │ DRUMMER │  ← Mid-level synthesis
  │ (Tier 2)│  │ (Tier 2)│  │ (Tier 2)│     Theme grouping
  └────┬────┘  └────┬────┘  └────┬────┘
       │            │            │
  ┌────┼────┐  ┌───┼────┐  ┌────┼────┐
  │    │    │  │   │    │  │    │    │
 ┌▼┐  ┌▼┐  ┌▼┐ ┌▼┐ ┌▼┐ ┌▼┐ ┌▼┐ ┌▼┐ ┌▼┐
 │B│  │B│  │B│ │B│ │B│ │B│ │B│ │B│ │B│  ← BELTER agents
 └─┘  └─┘  └─┘ └─┘ └─┘ └─┘ └─┘ └─┘ └─┘     Broad exploration
```

## When to Use

- **Complex research** requiring multiple angles
- **Comprehensive reports** on broad topics
- **Multi-source synthesis** (academic, news, web)
- **Long-form content** needing structured organization
- **Deep dives** into unfamiliar domains

## Scripts

### Start Research Workflow
```bash
scripts/cascade-research.py "Research topic" --belters 5 --drummers 2
scripts/cascade-research.py "AI safety implications" --provider xai --stream
```

### Check Workflow Status
```bash
scripts/cascade-status.py workflow-abc123
scripts/cascade-status.py --list  # Show all active workflows
```

### List Orchestrator Patterns
```bash
scripts/list-patterns.py
```

## Configuration Options

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--belters` | 5 | Number of Tier 1 exploration agents (1-10) |
| `--drummers` | 2 | Number of Tier 2 synthesis agents (1-5) |
| `--caminas` | 1 | Number of Tier 3 executive agents (1-3) |
| `--provider` | xai | LLM provider (xai, anthropic, openai, etc.) |
| `--model` | grok-3 | Model to use |
| `--stream` | false | Enable real-time SSE streaming |
| `--webhook` | none | URL for async notifications |
| `--output` | stdout | Output format (stdout, json, markdown) |

## Example Workflows

### Academic Research
```bash
scripts/cascade-research.py "Quantum computing applications in cryptography" \
  --belters 8 --drummers 3 --output markdown
```

### Market Analysis
```bash
scripts/cascade-research.py "Electric vehicle market trends 2025" \
  --belters 6 --drummers 2 --provider anthropic
```

### Technical Deep Dive
```bash
scripts/cascade-research.py "WebAssembly runtime optimization techniques" \
  --belters 5 --drummers 2 --stream
```

## Output Structure

Dream Cascade produces structured output:

```json
{
  "task_id": "workflow-abc123",
  "status": "completed",
  "result": {
    "executive_summary": "...",
    "key_findings": [...],
    "detailed_analysis": {...},
    "sources": [...],
    "recommendations": [...]
  },
  "metadata": {
    "total_agents": 8,
    "execution_time": 45.2,
    "total_cost": 0.05
  }
}
```

## Prerequisites

- MCP server running on port 5060
- Valid API keys configured in `~/documentation/API_KEYS.md`
- Python 3.10+ with requests library

## Troubleshooting

**"Connection refused"**: Start MCP server with `sm start mcp-orchestrator`

**"Provider not configured"**: Check API key in `~/.env` or `API_KEYS.md`

**"Workflow timeout"**: Increase timeout or reduce agent count

## Related Skills

- **dream-swarm** - Multi-domain parallel search
- **data-fetch** - Direct data source access
- **code-quality** - Code analysis workflows
