---
name: humanize
description: Remove AI writing indicators from documentation files. Use when (1) editing README files, (2) creating user-facing content, (3) cleaning up generated docs, (4) preparing content for publication.
---

# Humanize Skill

Remove AI writing indicators and patterns from documentation to create natural, human-sounding content.

## Quick Commands

```bash
humanize file.md                    # Fix with default threshold (0.8)
humanize file.md --preview          # Show diff without applying
humanize file.md --confidence 0.9   # Higher confidence threshold
humanize projects/wordblocks/       # Process directory recursively
humanize --batch file1.md file2.md  # Multiple files
humanize README.md --yes            # Auto-apply without confirmation
```

## What Gets Fixed

### High-Confidence Indicators (>0.9)
- "In this [section/guide/tutorial]..." → Direct statements
- "It's important to note that..." → Remove filler
- "Let's explore..." → Direct action
- "Please note that..." → Remove hedging
- Excessive bullet points → Natural paragraphs
- Over-structured lists → Flowing text

### Medium-Confidence Indicators (0.7-0.9)
- Overly formal transitions
- Redundant clarifications
- Generic examples
- Template-style headers
- Passive voice constructions

### Low-Confidence Indicators (0.6-0.7)
- Suggest for review but don't auto-fix
- May be legitimate style choices

## Detection Patterns

The humanizer identifies AI writing through:

1. **Phrase Patterns**: Common AI phrases like "delve into", "leverage", "robust"
2. **Structure Patterns**: Excessive symmetry, numbered lists everywhere
3. **Meta-Commentary**: Explaining what the text will do instead of doing it
4. **Hedging Language**: "Might", "perhaps", "it's worth noting"
5. **Generic Examples**: Placeholder-style examples (foo, bar, example1)

## Confidence Levels

| Level | Range | Behavior |
|-------|-------|----------|
| **High** | 0.9-1.0 | Auto-fix with `--yes` |
| **Medium** | 0.7-0.9 | Show suggestion, require approval |
| **Low** | 0.6-0.7 | Report only in preview mode |

Adjust threshold with `--confidence <value>`:
```bash
humanize file.md --confidence 0.95  # Only fix very obvious patterns
humanize file.md --confidence 0.6   # More aggressive fixing
```

## Safety Features

### Preview Mode
See changes before applying:
```bash
humanize README.md --preview
```

Output shows:
- Detected indicators with confidence scores
- Proposed changes as unified diff
- Summary statistics
- No files modified

### Backup Creation
When modifying files, humanize creates:
```
original_file.md → original_file.md.backup
```

Restore with:
```bash
mv file.md.backup file.md
```

### Confirmation Prompts
By default, humanize asks before applying changes:
```
Found 5 AI indicators in README.md
  - "In this guide" (confidence: 0.92)
  - "It's important to note" (confidence: 0.95)
  - "Let's explore" (confidence: 0.88)

Apply changes? [y/N]:
```

Skip prompts with `--yes` flag.

## Examples

### Single File with Preview
```bash
$ humanize README.md --preview

Analyzing: README.md
==================
Found 7 indicators:

1. Line 12: "In this section" → Remove meta-commentary (0.92)
2. Line 23: "It's important to note that" → Direct statement (0.95)
3. Line 45: "Let's explore the features" → "The features are" (0.88)
4. Line 67: "Please note that" → Remove hedging (0.91)

Preview of changes:
--- README.md
+++ README.md
@@ -12,7 +12,7 @@
-In this section, we'll cover the installation process.
+## Installation
...

No changes applied (preview mode).
```

### Batch Processing
```bash
$ humanize projects/wordblocks/ --confidence 0.85

Processing directory: projects/wordblocks/
Found 3 markdown files:
  - README.md (8 indicators)
  - CONTRIBUTING.md (3 indicators)
  - docs/API.md (12 indicators)

Process all files? [y/N]: y

Fixed README.md (8 changes)
Fixed CONTRIBUTING.md (3 changes)
Fixed docs/API.md (12 changes)

Summary: 23 total fixes across 3 files
```

### Integration with geepers_humanizer
For complex cases requiring context-aware humanization:
```bash
humanize large-doc.md --agent
```

This launches the geepers_humanizer agent which:
- Understands document structure
- Preserves technical accuracy
- Maintains consistent voice
- Handles edge cases intelligently

## File Type Support

Currently supported:
- `.md` (Markdown)
- `.html` (HTML content)
- `.txt` (Plain text)

Preserves:
- Code blocks (fenced with ``` or indented)
- Inline code (`code`)
- Technical terms in context
- Intentional formatting
- Links and references

## Common Patterns Fixed

### Before
```markdown
In this guide, we'll explore how to install the application.
It's important to note that you'll need Python 3.8 or higher.
Let's dive into the installation process.
```

### After
```markdown
## Installation

Requires Python 3.8 or higher.
```

### Before
```markdown
Please note that this feature is currently experimental and
might not work in all cases. It's worth mentioning that...
```

### After
```markdown
This feature is experimental and may not work in all cases.
```

## Workflow Integration

### Pre-commit Hook
Add to `.git/hooks/pre-commit`:
```bash
#!/bin/bash
for file in $(git diff --cached --name-only | grep -E '\\.md$'); do
    humanize "$file" --yes --confidence 0.9
    git add "$file"
done
```

### Documentation Pipeline
```bash
# Generate docs
./generate-docs.sh

# Clean up AI patterns
humanize docs/ --confidence 0.85 --yes

# Review changes
git diff docs/
```

### README Maintenance
```bash
# After editing README
humanize README.md --preview
# Review suggestions, then apply
humanize README.md --yes
```

## Related Skills

- **frontend-design** - For user-facing web content
- **feature-dev** - Documentation in feature development
- **commit-commands** - Clean docs before commits

## Troubleshooting

**Too many false positives**:
```bash
humanize file.md --confidence 0.95  # Raise threshold
```

**Missing obvious patterns**:
```bash
humanize file.md --confidence 0.6   # Lower threshold
```

**Want to review everything**:
```bash
humanize file.md --preview          # See all suggestions
```

**Accidentally modified wrong file**:
```bash
mv file.md.backup file.md           # Restore from backup
```

## Advanced Usage

### Custom Patterns
For project-specific patterns, use the agent:
```bash
humanize docs/ --agent --patterns project-patterns.json
```

### Ignore Specific Sections
Add markers to preserve sections:
```markdown
<!-- humanize-ignore-start -->
This text will be preserved exactly as-is.
<!-- humanize-ignore-end -->
```

### Diff-Only Mode
Generate diff file without modifying:
```bash
humanize README.md --diff-only > changes.diff
patch -p0 < changes.diff  # Apply later if desired
```

## Performance

- Single file: ~50ms
- Directory (10 files): ~500ms
- Large file (1000 lines): ~200ms

For very large projects, use:
```bash
humanize large-project/ --parallel 4  # Process 4 files at once
```
