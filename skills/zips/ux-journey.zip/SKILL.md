---
name: ux-journey
description: "Comprehensive UX analysis coordinating design, accessibility, and gamification agents for user flow and interaction evaluation."
---

# UX Journey Analysis

You are conducting a comprehensive user experience analysis. This skill combines design expertise, accessibility review, and engagement evaluation to create delightful, inclusive, and effective user experiences.

## UX Analysis Domains

### 1. Design System & Visual Hierarchy (@geepers_design)

**Swiss Design Principles:**
- Grid systems and mathematical precision
- Typography hierarchy (size, weight, color)
- Whitespace and rhythm
- Color application (purposeful, not decorative)
- Consistency across components

**Evaluation Criteria:**
- Does the eye flow naturally through the interface?
- Is importance clearly communicated?
- Are patterns repeated predictably?
- Is contrast sufficient (4.5:1 text, 3:1 UI)?

### 2. Accessibility & Inclusive Design (@geepers_a11y)

**WCAG 2.1 AA Compliance:**
- Keyboard navigation
- Screen reader support
- Touch targets (44x44px minimum)
- Color independence
- Motion sensitivity (prefers-reduced-motion)
- Cognitive accessibility

**AAC-Specific Considerations (if applicable):**
- Symbol clarity
- Large touch targets for motor accessibility
- Predictable navigation
- High-frequency word prioritization

### 3. Engagement & Gamification (@geepers_game)

**Core Loop Analysis:**
- What is the fundamental interaction pattern?
- Is there clear progression?
- Are loops satisfying and complete?

**Feedback Systems:**
- How does the system communicate success/failure?
- Is feedback immediate and satisfying?
- Are there visual, auditory cues?

**Reward Structures:**
- What rewards does the system offer?
- Are rewards frequent enough?
- Is there variety (intrinsic/extrinsic)?

### 4. Interaction Patterns (@geepers_design)

**User Flow Analysis:**
- Navigation clarity
- Form interactions
- Error handling and recovery
- Loading states and feedback
- Mobile considerations

## Execution Strategy

**Launch agents in PARALLEL:**

```
1. @geepers_design - Visual design and hierarchy review
2. @geepers_a11y - Accessibility audit
3. @geepers_design - Interaction pattern analysis
4. @geepers_game - Engagement and gamification opportunities
```

## UX Evaluation Framework

### The 5 E's of UX

1. **Effective** - Can users accomplish their goals?
2. **Efficient** - How quickly can they do it?
3. **Engaging** - Is the experience enjoyable?
4. **Error-tolerant** - How gracefully does it handle mistakes?
5. **Easy to learn** - Can new users figure it out?

### Emotional Journey Mapping

Track user emotions through the flow:
- Delight - Exceeds expectations
- Neutral - Meets expectations
- Frustration - Below expectations
- Abandonment - Complete failure

## When to Use UX Journey

- **New feature design** - Before building
- **Post-implementation review** - After building
- **User feedback analysis** - When users report issues
- **Competitive analysis** - Comparing to alternatives
- **Periodic review** - Quarterly UX health checks

## Related Skills

- **quality** - Includes accessibility as part of broader audit
- **checkpoint** - Quick check may surface obvious UX issues
- **datavis** - For data visualization UX specifically
