---
name: geepers-publish
description: Publish datasets to Kaggle, HuggingFace, and GitHub. Use when (1) uploading new datasets, (2) updating existing datasets, (3) checking dataset status, (4) generating metadata files, (5) validating before publish.
aliases:
  - publish-kaggle
  - publish-huggingface
  - publish-github
  - publish-all
---

# Dataset Publishing Skill

Publish and manage datasets across Kaggle, HuggingFace, and GitHub.

## CRITICAL: Pre-Publish Steps

**ALWAYS run these before any publish operation:**

1. **Run /humanize** on all markdown files (README.md, HUGGINGFACE_README.md, descriptions)
2. **Validate metadata** format and length constraints
3. **Check authentication** is working

## Credentials Location

| Platform | Credential Location | How to Get |
|----------|---------------------|------------|
| **Kaggle** | `~/.kaggle/kaggle.json` | kaggle.com/settings → API → Create New Token |
| **HuggingFace** | `$HF_API_KEY` env var | huggingface.co/settings/tokens → Write access |
| **GitHub** | `gh` CLI auth | `gh auth login` |

### Kaggle Credentials Format
```json
{"username":"lucassteuber","key":"YOUR_API_KEY"}
```
Permissions: `chmod 600 ~/.kaggle/kaggle.json`

### HuggingFace Token
Environment variable: `HF_API_KEY` or `HF_TOKEN`
Current user: `lukeslp`

### GitHub CLI
Check: `gh auth status`

---

## WORKFLOW: New Dataset Publishing

### Step 1: Prepare Directory Structure

```
my-dataset/
├── data.json                    # Main data file(s)
├── dataset-metadata.json        # Kaggle metadata
├── HUGGINGFACE_README.md        # HF dataset card
├── README.md                    # General documentation
└── .zenodo.json                 # Optional: Zenodo metadata
```

### Step 2: Generate Metadata (if missing)

If files don't exist, create them with proper structure.

**Kaggle `dataset-metadata.json`:**
```json
{
  "title": "Dataset Name (6-50 chars)",
  "id": "lucassteuber/dataset-slug",
  "licenses": [{"name": "CC-BY-4.0"}],
  "subtitle": "Brief description (20-80 chars required)",
  "description": "# Title\n\nFull markdown description...",
  "keywords": ["tag1", "tag2"],
  "isPrivate": true
}
```

**IMPORTANT: Always create datasets as PRIVATE first.** Review and make public manually via web UI after verification.
```

**CONSTRAINTS:**
- Title: 6-50 characters (STRICT)
- Subtitle: 20-80 characters (STRICT)
- ID format: `username/slug` where slug is 3-50 chars, lowercase, hyphens OK

**HuggingFace `HUGGINGFACE_README.md`:**
```yaml
---
license: cc-by-4.0
task_categories:
  - feature-extraction
language:
  - en
tags:
  - geography
pretty_name: Dataset Name
size_categories:
  - 10K<n<100K
---

# Dataset Name

Description...
```

**Valid HF licenses:** apache-2.0, mit, cc0-1.0, cc-by-4.0, cc-by-sa-4.0, cc-by-nc-4.0, odbl, gpl-3.0, lgpl-3.0, other

### Step 3: Humanize Documentation

**MANDATORY before publishing:**

```bash
/humanize README.md HUGGINGFACE_README.md dataset-metadata.json
```

Remove AI writing patterns:
- "This dataset provides/enables/offers..."
- "Comprehensive collection of..."
- Excessive bullet points
- Over-structured lists

### Step 4: Validate

Check all requirements before upload:

```bash
# Kaggle validation
kaggle datasets status lucassteuber/dataset-name  # Should return error if new

# HF validation - check README YAML
python3 -c "import yaml; yaml.safe_load(open('HUGGINGFACE_README.md').read().split('---')[1])"
```

### Step 5: Upload

**Kaggle Upload:**
```bash
cd /path/to/dataset
kaggle datasets create -p .
```

**HuggingFace Upload:**
```python
from huggingface_hub import HfApi, create_repo
import os

token = os.environ.get('HF_API_KEY')
api = HfApi(token=token)

# Create repo (PRIVATE by default)
repo_name = "lukeslp/dataset-name"
create_repo(repo_name, repo_type="dataset", exist_ok=True, private=True, token=token)

# Upload files
api.upload_file(
    path_or_fileobj="data.json",
    path_in_repo="data.json",
    repo_id=repo_name,
    repo_type="dataset",
    token=token
)

# Upload README (must be named README.md on HF)
api.upload_file(
    path_or_fileobj="HUGGINGFACE_README.md",
    path_in_repo="README.md",
    repo_id=repo_name,
    repo_type="dataset",
    token=token
)
```

**GitHub Release:**
```bash
cd /path/to/repo
gh release create v1.0.0 data.json --title "Dataset v1.0.0" --notes "Initial release"
```

### Step 6: Post-Upload Setup

Create `KAGGLE_SETUP.md` checklist for web UI tasks:
- Cover image (1200x630px)
- Provenance/data sources with URLs
- File descriptions
- Update frequency
- License details

---

## WORKFLOW: Update Existing Dataset

### Kaggle Version Update
```bash
cd /path/to/dataset
kaggle datasets version -p . -m "Added X records, fixed Y"
```

### HuggingFace Update
```python
# Same upload code - overwrites existing files
api.upload_file(...)
```

### Metadata-Only Update (Kaggle)

1. Download current metadata:
```bash
kaggle datasets metadata lucassteuber/dataset-name -p /tmp
```

2. The file is double-JSON-encoded. Parse and modify:
```python
import json
with open('/tmp/dataset-metadata.json') as f:
    data = json.loads(json.loads(f.read()))
data['isPrivate'] = False  # Make public
data['keywords'] = ['new', 'tags']
with open('/tmp/dataset-metadata.json', 'w') as f:
    f.write(json.dumps(json.dumps(data)))
```

3. Upload:
```bash
kaggle datasets metadata lucassteuber/dataset-name --update -p /tmp
```

---

## WORKFLOW: Check Status

### Kaggle
```bash
kaggle datasets status lucassteuber/dataset-name
kaggle datasets list --mine
```

### HuggingFace
```bash
huggingface-cli repo info lukeslp/dataset-name --repo-type dataset
```

---

## Common Issues & Fixes

### Kaggle 401 Unauthorized
```bash
# Regenerate token at kaggle.com/settings
# Replace ~/.kaggle/kaggle.json
chmod 600 ~/.kaggle/kaggle.json
```

### HuggingFace 403 Forbidden
- Token needs "Write" permission
- Create new token at huggingface.co/settings/tokens

### Kaggle Title/Subtitle Errors
- Title: exactly 6-50 characters
- Subtitle: exactly 20-80 characters
- Count characters and adjust

### HuggingFace License Error
Use exact IDs: `odbl` not `ODbL-1.0`, `cc-by-4.0` not `CC-BY-4.0`

### Kaggle Metadata Update 400 Error
- Keywords must exist in Kaggle's tag list
- Use minimal changes when updating
- Some fields can only be changed via web UI

---

## Platform-Specific Limits

### Kaggle
- Max file size: 20 GB per file
- Max dataset size: 100 GB total
- Rate limits: Be careful with rapid API calls

### HuggingFace
- Max file size: 50 GB (with Git LFS)
- Unlimited dataset size
- Rate limits: Generous but don't abuse

### GitHub Releases
- Max file size: 2 GB per file
- Use releases for data, not the repo itself

---

## Dataset Registry

Common paths for datasets ready to publish:

```
/home/coolhand/kaggle_datasets/
├── strange-places-mysterious-phenomena/   # 341K records, multi-source
├── waterfalls-worldwide/                  # 80K waterfalls, OSM
└── [future datasets]
```

---

## Making Datasets Public

**Datasets are created PRIVATE by default.** To make public after review:

### Kaggle
1. Go to dataset settings page
2. Change visibility to "Public"
3. Or via API (after review):
```python
# Download, modify, upload metadata
kaggle datasets metadata user/dataset -p /tmp
# Edit /tmp/dataset-metadata.json: "isPrivate": false
kaggle datasets metadata user/dataset --update -p /tmp
```

### HuggingFace
```python
from huggingface_hub import HfApi
api = HfApi(token=token)
api.update_repo_visibility("lukeslp/dataset-name", private=False, repo_type="dataset")
```

---

## Post-Publish Checklist Generator

After API upload, **automatically generate** `KAGGLE_SETUP.md` with the following template:

```markdown
# Kaggle Web UI Setup Checklist

Dataset: [DATASET_NAME]
URL: https://www.kaggle.com/datasets/lucassteuber/[SLUG]
Created: [DATE]

## 1. Cover Image (Required)

**Dimensions**: 1200 x 630 pixels (16:9 ratio)

**Design guidelines**:
- Simple, bold visual representing the data theme
- Title text overlay (optional but recommended)
- Swiss Design aesthetic: geometric, minimal, limited colors

**Tools**: Canva, Figma, or DALL-E generation

---

## 2. Provenance (Required)

### Data Sources

| Source | URL | License | Access Date |
|--------|-----|---------|-------------|
| [SOURCE_1] | [URL] | [LICENSE] | [DATE] |

### Collection Methodology

[METHODOLOGY_TEXT - describe how data was collected, processed, and validated]

---

## 3. File Descriptions

| Filename | Description |
|----------|-------------|
| [FILE_1] | [DESCRIPTION] |

---

## 4. Settings

- **Visibility**: Private (make public after review)
- **License**: [LICENSE_NAME]
- **Expected Update Frequency**: [FREQUENCY]
- **Tags**: [TAG_LIST]

---

## 5. Post-Setup Verification

- [ ] Cover image uploaded and displays correctly
- [ ] Provenance section complete with all sources
- [ ] All files have descriptions
- [ ] License is correct
- [ ] Tags are appropriate and discoverable
- [ ] Description renders properly (Markdown)
- [ ] Dataset is accessible (test download)
```

### Auto-Generation Script

After publishing, generate the setup file programmatically:

```python
from datetime import datetime
import json
from pathlib import Path

def generate_kaggle_setup(dataset_dir: Path, metadata: dict):
    """Generate KAGGLE_SETUP.md from dataset metadata."""

    template = f"""# Kaggle Web UI Setup Checklist

Dataset: {metadata.get('title', 'Unknown')}
URL: https://www.kaggle.com/datasets/{metadata.get('id', 'lucassteuber/unknown')}
Created: {datetime.now().strftime('%Y-%m-%d')}

## 1. Cover Image (Required)

**Dimensions**: 1200 x 630 pixels (16:9 ratio)

**Design guidelines**:
- Simple, bold visual representing the data theme
- Title text overlay (optional but recommended)
- Swiss Design aesthetic: geometric, minimal, limited colors

**Tools**: Canva, Figma, or DALL-E generation

---

## 2. Provenance (Required)

### Data Sources

| Source | URL | License | Access Date |
|--------|-----|---------|-------------|
| TODO | TODO | TODO | {datetime.now().strftime('%Y-%m-%d')} |

### Collection Methodology

TODO: Describe how data was collected, processed, and validated.

---

## 3. File Descriptions

| Filename | Description |
|----------|-------------|
"""

    # Add file descriptions
    for f in dataset_dir.glob('*.json'):
        if f.name != 'dataset-metadata.json':
            template += f"| {f.name} | TODO: Add description |\n"
    for f in dataset_dir.glob('*.csv'):
        template += f"| {f.name} | TODO: Add description |\n"
    for f in dataset_dir.glob('*.parquet'):
        template += f"| {f.name} | TODO: Add description |\n"

    template += f"""
---

## 4. Settings

- **Visibility**: Private (make public after review)
- **License**: {metadata.get('licenses', [{}])[0].get('name', 'TODO')}
- **Expected Update Frequency**: As needed / Quarterly / Annually
- **Tags**: {', '.join(metadata.get('keywords', ['TODO']))}

---

## 5. Post-Setup Verification

- [ ] Cover image uploaded and displays correctly
- [ ] Provenance section complete with all sources
- [ ] All files have descriptions
- [ ] License is correct
- [ ] Tags are appropriate and discoverable
- [ ] Description renders properly (Markdown)
- [ ] Dataset is accessible (test download)
"""

    setup_path = dataset_dir / 'KAGGLE_SETUP.md'
    setup_path.write_text(template)
    print(f"Generated: {setup_path}")
    return setup_path


# Usage in publish workflow:
# generate_kaggle_setup(Path('/path/to/dataset'), metadata_dict)
```

---

## Integration with Other Skills

- **/humanize** - ALWAYS run before publish
- **@geepers_data** - Data validation
- **@geepers_docs** - Documentation generation
- **@geepers_citations** - Verify source citations

---

## Quick Reference

| Action | Kaggle | HuggingFace | GitHub |
|--------|--------|-------------|--------|
| Create | `kaggle datasets create -p .` | `create_repo()` + `upload_file()` | `gh release create` |
| Update | `kaggle datasets version -p . -m "msg"` | `upload_file()` (overwrites) | `gh release upload --clobber` |
| Status | `kaggle datasets status user/name` | `huggingface-cli repo info` | `gh release list` |
| Delete | Web UI only | `api.delete_repo()` | `gh release delete` |
