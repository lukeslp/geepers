---
name: geepers-team
description: All-hands parallel agent dispatch. Throws every relevant geepers agent at a problem simultaneously. Use when (1) starting a major project audit, (2) doing a comprehensive pre-release review, (3) you want maximum coverage fast, (4) onboarding to an unfamiliar codebase. Unlike /swarm (parallel data search) or geepers-cascade (hierarchical research), this dispatches code-focused agents in parallel.
---

# Geepers Team - All-Hands Dispatch

Launch multiple geepers agents in parallel against the current project. Maximum coverage, minimum time.

## How It Works

Geepers Team analyzes the project context and dispatches the right combination of agents simultaneously using the Task tool with `run_in_background: true`. Results are collected and synthesized into a unified report.

## Dispatch Profiles

### `/geepers-team audit` - Full Project Audit
Dispatches in parallel:
- `geepers_scout` - Project reconnaissance
- `geepers_a11y` - Accessibility review
- `geepers_perf` - Performance review
- `geepers_security` - Security audit
- `geepers_deps` - Dependency check
- `geepers_testing` - Test coverage analysis
- `geepers_critic` - Architecture critique

### `/geepers-team frontend` - Frontend Blitz
Dispatches in parallel:
- `geepers_css` - Style audit
- `geepers_typescript` - Type safety
- `geepers_webperf` - Web performance
- `geepers_a11y` - Accessibility
- `geepers_uxpert` - UX patterns
- `geepers_motion` - Animation review
- `geepers_design` - Design system check

### `/geepers-team backend` - Backend Blitz
Dispatches in parallel:
- `geepers_api` - API design review
- `geepers_db` - Database patterns
- `geepers_security` - Security audit
- `geepers_perf` - Performance
- `geepers_deps` - Dependencies
- `geepers_testing` - Test coverage

### `/geepers-team ship` - Pre-Ship Checklist
Dispatches in parallel:
- `geepers_validator` - Config validation
- `geepers_security` - Security scan
- `geepers_a11y` - Accessibility
- `geepers_testing` - Tests pass
- `geepers_deps` - No vulnerable deps
- `geepers_humanizer` - Docs quality
- `geepers_git` - Clean git state

### `/geepers-team onboard` - Learn a Codebase
Dispatches in parallel:
- `geepers_scout` - Structure overview
- `geepers_system_onboard` - Architecture map
- `geepers_deps` - Tech stack
- `geepers_api` - API surface
- `geepers_db` - Data model
- `geepers_snippets` - Key patterns

### `/geepers-team everything` - The Kitchen Sink
Dispatches ALL quality + infrastructure + frontend agents. Use sparingly - this is 15+ parallel agents.

## Execution Pattern

```
1. Analyze project type (frontend, backend, fullstack, etc.)
2. Select dispatch profile (or use explicit profile from args)
3. Launch all agents via Task tool with run_in_background: true
4. Collect results as agents complete
5. Synthesize into unified findings report
6. Deduplicate overlapping recommendations
7. Present prioritized action items
```

## Usage

```
/geepers-team                    # Auto-detect project type, run audit
/geepers-team audit              # Full quality audit
/geepers-team frontend           # Frontend-focused review
/geepers-team backend            # Backend-focused review
/geepers-team ship               # Pre-release checklist
/geepers-team onboard            # Understand a new codebase
/geepers-team everything         # Every agent at once
```

## How This Differs From Other Skills

| Skill | What It Does |
|-------|-------------|
| `/swarm` | Parallel **data search** across external APIs (arXiv, GitHub, news) |
| `/geepers-cascade` | Hierarchical **research** workflow (explore, synthesize, report) |
| `/geepers-team` | Parallel **code agent** dispatch against the current project |
| `geepers_conductor` | Intelligent **routing** to one or two agents based on intent |

`/geepers-team` is the brute-force option. `geepers_conductor` is the smart router. Use team when you want breadth; use conductor when you want precision.

## Output

Results are collected into `~/geepers/reports/by-date/YYYY-MM-DD/team-{profile}-{project}.md` with:
- Per-agent findings (collapsible sections)
- Cross-agent themes (deduplicated)
- Prioritized action items (critical → nice-to-have)
- Estimated effort per item
